#!/bin/bash

roslaunch humanoid_description humanoid_rviz.launch 
