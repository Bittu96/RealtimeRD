# humanoid_ws
URDF model for Gazebo integrated with ROS
